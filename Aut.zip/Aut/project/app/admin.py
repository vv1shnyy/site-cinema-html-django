from django.contrib import admin
from .models import Transport, Request

@admin.register(Transport)
class TransportAdmin(admin.ModelAdmin):
    list_display = ['name']

@admin.register(Request)
class RequestAdmin(admin.ModelAdmin):
    list_display = ['user', 'transport', 'start_date', 'payment', 'status']
    list_filter = ['status', 'payment']