from django import forms
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
import re
from .models import Request

class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, min_length=8, label='Пароль')
    confirm = forms.CharField(widget=forms.PasswordInput, label='Подтверждение')
    full_name = forms.CharField(label='ФИО')
    birth = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), label='Дата рождения')
    phone = forms.CharField(label='Телефон')
    email = forms.EmailField(label='E-mail')

    class Meta:
        model = User
        fields = ['username', 'password']
        labels = {'username': 'Логин'}

    def clean_username(self):
        u = self.cleaned_data['username']
        if not re.match(r'^[A-Za-z0-9]{6,}$', u):
            raise ValidationError('Логин: латиница и цифры, мин 6')
        if User.objects.filter(username=u).exists():
            raise ValidationError('Логин занят')
        return u

    def clean(self):
        if self.cleaned_data.get('password') != self.cleaned_data.get('confirm'):
            raise ValidationError('Пароли не совпадают')

class RequestForm(forms.ModelForm):
    class Meta:
        model = Request
        fields = ['transport', 'start_date', 'payment']
        widgets = {'start_date': forms.DateInput(attrs={'type': 'date'})}
        labels = {
            'transport': 'Вид транспорта',
            'start_date': 'Дата начала',
            'payment': 'Способ оплаты'
        }