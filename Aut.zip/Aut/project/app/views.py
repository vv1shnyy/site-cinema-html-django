from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from .forms import RegisterForm, RequestForm
from .models import Request, Transport

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect('profile')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user:
            login(request, user)
            return redirect('profile')
    return render(request, 'login.html', {'error': 'Неверный логин или пароль' if request.POST else ''})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def profile(request):
    requests = Request.objects.filter(user=request.user)
    if request.method == 'POST' and 'review' in request.POST:
        req = Request.objects.get(id=request.POST['req_id'], user=request.user)
        if req.status == 'done':
            req.review = request.POST['review']
            req.save()
    return render(request, 'profile.html', {'requests': requests})

@login_required
def create_request(request):
    if request.method == 'POST':
        form = RequestForm(request.POST)
        if form.is_valid():
            req = form.save(commit=False)
            req.user = request.user
            req.save()
            return redirect('profile')
    else:
        form = RequestForm()
    return render(request, 'create.html', {'form': form, 'transports': Transport.objects.all()})

@staff_member_required
def admin_panel(request):
    requests = Request.objects.all()
    if request.method == 'POST':
        req = Request.objects.get(id=request.POST['req_id'])
        req.status = request.POST['status']
        req.save()
    return render(request, 'admin.html', {'requests': requests})