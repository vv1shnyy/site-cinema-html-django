from django.db import models
from django.contrib.auth.models import User

class Transport(models.Model):
    name = models.CharField('Название', max_length=100)

    class Meta:
        verbose_name = 'Вид транспорта'
        verbose_name_plural = 'Виды транспорта'

    def __str__(self):
        return self.name

class Request(models.Model):
    STATUS = [('new', 'Новая'), ('study', 'Идет обучение'), ('done', 'Обучение завершено')]
    PAY = [('cash', 'Наличные'), ('card', 'Карта'), ('online', 'Онлайн')]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Пользователь')
    transport = models.ForeignKey(Transport, on_delete=models.SET_NULL, null=True, verbose_name='Транспорт')
    start_date = models.DateField(verbose_name='Дата начала')
    payment = models.CharField('Оплата', max_length=10, choices=PAY)
    status = models.CharField('Статус', max_length=10, choices=STATUS, default='new')
    review = models.TextField('Отзыв', blank=True, null=True)

    class Meta:
        verbose_name = 'Заявка'
        verbose_name_plural = 'Заявки'

    def __str__(self):
        return f'{self.user} - {self.transport}'