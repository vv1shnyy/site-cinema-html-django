from django.contrib import admin
from .models import *

admin.site.register(Films)
admin.site.register(Serials)
admin.site.register(Sub)
admin.site.register(Profile)
admin.site.register(Comedy)
