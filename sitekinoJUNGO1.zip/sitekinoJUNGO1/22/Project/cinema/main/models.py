from django.db import models
from django.contrib.auth.models import User 

class Films(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.TextField()

class Serials(models.Model):
    count = models.IntegerField()
    data = models.DateField()


class Sub(models.Model):

    Adress = models.TextField()
    Birthday = models.DateField()
    Post = models.TextField()
    Salary = models.IntegerField()

class Profile(models.Model):
    price = models.IntegerField()

class Comedy(models.Model):
    title = models.TextField()
    country = models.TextField()
