from django.db import models


class Habit(models.Model):
    name = models.CharField(max_length=255, verbose_name="Название привычки")
    description = models.TextField(blank=True, null=True, verbose_name="Описание")
    time = models.TimeField(verbose_name="Время выполнения")
    times_per_day = models.PositiveIntegerField(default=1, verbose_name="Количество выполнений в день")
    max_days = models.PositiveIntegerField(blank=True, null=True, verbose_name="Максимальное количество дней")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")
    streak = models.PositiveIntegerField(default=0, verbose_name="Дней подряд выполнено")

    def __str__(self):
        return self.name

class HabitCompletion(models.Model):
    habit = models.ForeignKey(Habit, on_delete=models.CASCADE, related_name="completions")
    date = models.DateField(max_length=100)

    def __str__(self):
        return f"{self.habit.name} - {self.date}"
    
    