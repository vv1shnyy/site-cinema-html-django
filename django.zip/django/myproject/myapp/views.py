from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import Habit, HabitCompletion

# Список всех привычек
class HabitListView(ListView):
    model = Habit
    template_name = 'habits/habit_list.html'
    context_object_name = 'habits'

# Детали одной привычки
class HabitDetailView(DetailView):
    model = Habit
    template_name = 'habits/habit_detail.html'
    context_object_name = 'habit'

# Создание новой привычки
class HabitCreateView(CreateView):
    model = Habit
    template_name = 'habits/habit_form.html'
    fields = ['name', 'description', 'time', 'times_per_day', 'max_days']
    success_url = reverse_lazy('habit-list')

# Редактирование привычки
class HabitUpdateView(UpdateView):
    model = Habit
    template_name = 'habits/habit_form.html'
    fields = ['name', 'description', 'time', 'times_per_day', 'max_days']
    success_url = reverse_lazy('habit-list')

# Удаление привычки
class HabitDeleteView(DeleteView):
    model = Habit
    template_name = 'habits/habit_confirm_delete.html'
    success_url = reverse_lazy('habit-list')

# Список выполненных привычек
class HabitCompletionListView(ListView):
    model = HabitCompletion
    template_name = 'habits/habit_completion_list.html'
    context_object_name = 'completions'

# Создание записи о выполнении привычки
class HabitCompletionCreateView(CreateView):
    model = HabitCompletion
    template_name = 'habits/habit_completion_form.html'
    fields = ['habit', 'date']
    success_url = reverse_lazy('habit-completion-list')