from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse
from .models import Habit, HabitCompletion

# Список всех привычек
def habit_list(request):
    habits = Habit.objects.all()
    return render(request, 'habits/habit_list.html', {'habits': habits})

# Детали одной привычки
def habit_detail(request, pk):
    habit = get_object_or_404(Habit, pk=pk)
    completions = HabitCompletion.objects.filter(habit=habit)
    return render(request, 'habits/habit_detail.html', {'habit': habit, 'completions': completions})

# Создание новой привычки
def habit_create(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        time = request.POST.get('time')
        times_per_day = request.POST.get('times_per_day')
        max_days = request.POST.get('max_days')

        habit = Habit.objects.create(
            name=name,
            description=description,
            time=time,
            times_per_day=times_per_day,
            max_days=max_days,
        )
        return redirect('habit-detail', pk=habit.pk)
    return render(request, 'habits/habit_form.html')

# Редактирование привычки
def habit_update(request, pk):
    habit = get_object_or_404(Habit, pk=pk)
    if request.method == 'POST':
        habit.name = request.POST.get('name')
        habit.description = request.POST.get('description')
        habit.time = request.POST.get('time')
        habit.times_per_day = request.POST.get('times_per_day')
        habit.max_days = request.POST.get('max_days')
        habit.save()
        return redirect('habit-detail', pk=habit.pk)
    return render(request, 'habits/habit_form.html', {'habit': habit})

# Удаление привычки
def habit_delete(request, pk):
    habit = get_object_or_404(Habit, pk=pk)
    if request.method == 'POST':
        habit.delete()
        return redirect('habit-list')
    return render(request, 'habits/habit_confirm_delete.html', {'habit': habit})

# Создание записи о выполнении привычки
def habit_completion_create(request, habit_pk):
    habit = get_object_or_404(Habit, pk=habit_pk)
    if request.method == 'POST':
        date = request.POST.get('date')
        HabitCompletion.objects.create(habit=habit, date=date)
        return redirect('habit-detail', pk=habit.pk)
    return render(request, 'habits/habit_completion_form.html', {'habit': habit})