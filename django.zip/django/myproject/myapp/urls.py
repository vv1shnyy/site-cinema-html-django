from django.urls import path
from . import views  # Импортируйте ваши views

urlpatterns = [
    path('habit_create/', habit_create, name='habit_create'),
    # Добавьте другие маршруты здесь
]