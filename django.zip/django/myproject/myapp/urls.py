from django.urls import path
from .views import HabitAPI, HabitCompletionAPI

urlpatterns = [
    path('habits/', HabitAPI.as_view(), name='habit-api'),
    path('habit-completions/', HabitCompletionAPI.as_view(), name='habit-completion-api'),
]