from django.http import JsonResponse, HttpResponseBadRequest, HttpResponseNotFound
from django.urls import reverse
from django.views.decorators.http import require_http_methods
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from .models import Tag, Habit, Challenge, UserProfile, HabitLog
from django.forms.models import model_to_dict
import json
from datetime import datetime

def parse_date(date_str):
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else None
    except ValueError:
        return None

@require_http_methods(["GET"])
def get_habits(request):
    habits = list(Habit.objects.values(
        'id', 'name', 'description', 'user__username',
        'target_streak', 'current_streak', 'frequency',
        'is_active', 'created_at'
    ))
    return JsonResponse({
        "data": habits,
        "links": {
            "self": request.build_absolute_uri(),
            "create": request.build_absolute_uri(reverse('create-habit'))
        }
    })

@require_http_methods(["POST"])
def create_habit(request):
    try:
        data = json.loads(request.body)
        user = User.objects.get(pk=data['user_id'])
        
        habit = Habit.objects.create(
            user=user,
            name=data['name'],
            description=data.get('description', ''),
            target_streak=data.get('target_streak', 21),
            frequency=data.get('frequency', Habit.DAILY)
        )
        
        if 'tags' in data:
            habit.tags.set(data['tags'])
            
        return JsonResponse(model_to_dict(habit), status=201)
    except Exception as e:
        return HttpResponseBadRequest(f"Error: {str(e)}")

@require_http_methods(["GET"])
def habit_detail(request, habit_id):
    habit = get_object_or_404(Habit, pk=habit_id)
    return JsonResponse(model_to_dict(habit))

@require_http_methods(["GET"])
def get_habit_logs(request, habit_id):
    logs = list(HabitLog.objects.filter(habit_id=habit_id).values(
        'id', 'date', 'is_completed', 'notes'
    ))
    return JsonResponse({"data": logs})

@require_http_methods(["POST"])
def log_habit(request, habit_id):
    try:
        data = json.loads(request.body)
        habit = Habit.objects.get(pk=habit_id)
        
        log, created = HabitLog.objects.get_or_create(
            habit=habit,
            date=parse_date(data['date']),
            defaults={'is_completed': data.get('is_completed', False)}
        )
        
        if not created:
            log.is_completed = data.get('is_completed', log.is_completed)
            log.save()
        
        if log.is_completed:
            habit.current_streak += 1
            habit.save()
            profile = habit.user.profile
            profile.streak_days = max(profile.streak_days, habit.current_streak)
            profile.save()
        
        return JsonResponse(model_to_dict(log), status=201 if created else 200)
    except Exception as e:
        return HttpResponseBadRequest(f"Error: {str(e)}")

@require_http_methods(["GET"])
def get_challenges(request):
    challenges = list(Challenge.objects.values(
        'id', 'title', 'description', 'start_date',
        'end_date', 'created_at'
    ))
    return JsonResponse({"data": challenges})

@require_http_methods(["POST"])
def create_challenge(request):
    try:
        data = json.loads(request.body)
        challenge = Challenge.objects.create(
            title=data['title'],
            description=data.get('description', ''),
            start_date=parse_date(data['start_date']),
            end_date=parse_date(data['end_date'])
        )
        
        if 'habits' in data:
            challenge.habits.set(data['habits'])
        if 'tags' in data:
            challenge.tags.set(data['tags'])
            
        return JsonResponse(model_to_dict(challenge), status=201)
    except Exception as e:
        return HttpResponseBadRequest(f"Error: {str(e)}")

@require_http_methods(["GET"])
def challenge_detail(request, challenge_id):
    challenge = get_object_or_404(Challenge, pk=challenge_id)
    return JsonResponse(model_to_dict(challenge))

@require_http_methods(["GET"])
def get_tags(request):
    tags = list(Tag.objects.values('id', 'name', 'slug', 'created_at'))
    return JsonResponse({"data": tags})

@require_http_methods(["POST"])
def create_tag(request):
    try:
        data = json.loads(request.body)
        tag = Tag.objects.create(name=data['name'])
        return JsonResponse(model_to_dict(tag), status=201)
    except Exception as e:
        return HttpResponseBadRequest(f"Error: {str(e)}")

@require_http_methods(["GET"])
def get_user_stats(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    stats = {
        'total_habits': Habit.objects.filter(user=user).count(),
        'completed_logs': HabitLog.objects.filter(habit__user=user, is_completed=True).count(),
        'current_streak': user.profile.streak_days
    }
    return JsonResponse(stats)