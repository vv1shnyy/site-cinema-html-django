from django.urls import path
from . import views

urlpatterns = [
    path('habits/', views.get_habits, name='get-habits'),
    path('habits/create/', views.create_habit, name='create-habit'),
    path('habits/<int:habit_id>/', views.habit_detail, name='habit-detail'),
    path('habits/<int:habit_id>/logs/', views.get_habit_logs, name='habit-logs'),
    path('habits/<int:habit_id>/log/', views.log_habit, name='log-habit'),
    
    path('challenges/', views.get_challenges, name='get-challenges'),
    path('challenges/create/', views.create_challenge, name='create-challenge'),
    path('challenges/<int:challenge_id>/', views.challenge_detail, name='challenge-detail'),
    
    path('tags/', views.get_tags, name='get-tags'),
    path('tags/create/', views.create_tag, name='create-tag'),
    
    path('users/<int:user_id>/stats/', views.get_user_stats, name='user-stats'),
]