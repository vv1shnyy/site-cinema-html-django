from django.db import models
from django.contrib.auth.models import User

class Genre(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Movie(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    release_date = models.DateField()
    poster = models.ImageField(upload_to='posters/')
    genres = models.ManyToManyField(Genre)

    def __str__(self):
        return self.title


class Episode(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    audio_file = models.FileField(upload_to='episodes/')
    publication_date = models.DateTimeField(auto_now_add=True)
    duration = models.DurationField()
    is_published = models.BooleanField(default=False)

    def __str__(self):
        return self.title

class Subscription(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()

    def __str__(self):
        return f"{self.user.username}'s Subscription"