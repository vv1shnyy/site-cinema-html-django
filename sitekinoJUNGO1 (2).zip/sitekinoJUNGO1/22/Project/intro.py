from functools import lru_cache


class MyClass:
    field1 = 12
    field2 = 'asd'

    def my_method(self, p1, p2):
        self.field1 = p1 + p2

    def __init__(self, var1): 
        self.field3 = True

    def _private_method(self, f2):
        self.field2 = f2


class Anceptor(MyClass):
    field4 = [1, 2, 3]


anceptor = MyClass(123)
anceptor.my_method(p1=3, p2=5)
print(anceptor.field1) 
print(anceptor.field4)