class Vector:
    def __init__(self, g1, g2):
        self.g1 = g1
        self.g2 = g2

    def add(self, other):
        if isinstance(other, Vector):
            return Vector(self.g1 + other.g1, self.g2 + other.g2)
        return NotImplemented

    def sub(self, other):
        if isinstance(other, Vector):
            return Vector(self.g1 - other.g1, self.g2 - other.g2)
        return NotImplemented

    def mul(self, scalar):
        return Vector(self.g1 * scalar, self.g2 * scalar)

    def repr(self):
        return f"Vector({self.g1}, {self.g2})"