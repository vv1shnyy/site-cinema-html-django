import functions 
from functions import add, sub
from functions import *

add(1,2)
sub(5, 2)