from django.shortcuts import HttpResponse

def add(request, a , b):
    return HttpResponse(a + b)